/**
 * 
 */
(function() {
  'use strict';

  angular
    .module('plunker')
    .service('dataService', dataServiceFn);

  dataServiceFn.$inject = ['$q', '$http'];

  function dataServiceFn($q, $http) {
    var self = this;

    self.getReserv = function() {
      var defer = $q.defer();

      $http({
          method: 'GET',
          url: '/api/user/getAll'
        })
        .success(function(data) {
          defer.resolve(data);
        })
        .error(function(err) {
          defer.reject(err);
        });

      return defer.promise;
    };
    
    self.getStatus = function(confirmNumb) {
        var defer = $q.defer();

        $http({
            method: 'GET',
            url: '/RestaurantMS/api/reservation/get/'+confirmNumb
          })
          .success(function(data) {
            defer.resolve(data);
          })
          .error(function(err) {
            defer.reject(err);
          });

        return defer.promise;
      };


//    self.getReservDetail = function(userid) {
//      var defer = $q.defer();
//
//      $http({
//          method: 'GET',
//          url: 'http://jsonplaceholder.typicode.com/users/' + userid
//        })
//        .success(function(data) {
//          defer.resolve(data);
//        })
//        .error(function(err) {
//          defer.reject(err);
//        });
//
//      return defer.promise;
//    };

    self.title = 'not defined yet';

  }
})();